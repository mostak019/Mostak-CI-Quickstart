<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-26 03:46:22 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:54:54 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:56:15 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:56:18 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:56:19 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:56:19 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:56:19 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:58:03 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:58:12 --> 404 Page Not Found: /index
ERROR - 2019-04-26 03:58:23 --> 404 Page Not Found: /index
ERROR - 2019-04-26 04:00:16 --> 404 Page Not Found: /index
ERROR - 2019-04-26 04:03:21 --> 404 Page Not Found: /index
ERROR - 2019-04-26 04:03:22 --> 404 Page Not Found: /index
ERROR - 2019-04-26 04:15:05 --> 404 Page Not Found: /index
ERROR - 2019-04-26 04:15:05 --> 404 Page Not Found: /index
ERROR - 2019-04-26 04:15:05 --> 404 Page Not Found: /index
ERROR - 2019-04-26 04:15:05 --> 404 Page Not Found: /index
ERROR - 2019-04-26 04:15:06 --> 404 Page Not Found: /index
